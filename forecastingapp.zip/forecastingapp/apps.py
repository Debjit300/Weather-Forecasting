from django.apps import AppConfig


class ForecastingappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'forecastingapp'
